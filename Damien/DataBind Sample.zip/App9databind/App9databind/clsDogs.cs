﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App9databind
{
    class clsDogs
    {
        public string myBreedName { get; set; }
        public string origin { get; set; }
        public string category { get; set; }
        public string activity { get; set; }
        public string grooming { get; set; }
        public string imgBreed { get; set; }
    }
}
